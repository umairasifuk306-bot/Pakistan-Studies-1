# PMS Pakistan Studies-I (Android App)

Punjab PMS Pakistan Studies-I ke 80 topics, 400 headings: har heading ka Short, Long aur Study Points.
Offline chalti hai. Kotlin + Jetpack Compose.

## GitHub par upload aur APK banane ke steps

1. GitHub par naya repository banayein (Public ya Private).
2. Is ZIP ko extract karein aur **andar ki saari files aur folders** repository mein upload karein
   (`app`, `.github`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`, `.gitignore`, `README.md`).
   - Agar `.github` folder upload mein nahi aata, to repo mein **Add file > Create new file** dabayein,
     naam mein `.github/workflows/build.yml` likhein aur is file ka content paste karein.
3. Upload hote hi **Actions** tab mein "Build APK" khud chal jata hai (5-10 minute lagte hain).
4. Build khatam hone par us run par click karein, neeche **Artifacts** mein `PMS-PakStudies-APK` download karein.
   ZIP extract karein to `PMS-PakStudies.apk` milegi.
5. APK phone mein copy karke install karein (Settings mein "Install unknown apps" ki ijazat dein).

## Release ke taur par APK (optional)
Tag `v1.0` bana kar push karein; APK **Releases** page par lag jayegi.

## Data badalna
`app/src/main/assets/topics.json` mein notes hain. Docx se dobara banane ke liye `tools/convert.py` use karein.
