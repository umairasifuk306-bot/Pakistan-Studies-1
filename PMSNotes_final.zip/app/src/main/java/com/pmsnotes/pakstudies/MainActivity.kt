package com.pmsnotes.pakstudies

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.pmsnotes.pakstudies.data.AppViewModel
import com.pmsnotes.pakstudies.ui.AppNav
import com.pmsnotes.pakstudies.ui.PmsTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PmsTheme {
                val vm: AppViewModel = viewModel()
                AppNav(vm)
            }
        }
    }
}
