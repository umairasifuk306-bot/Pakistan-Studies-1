package com.pmsnotes.pakstudies.data

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json

class AppViewModel(app: Application) : AndroidViewModel(app) {

    var data by mutableStateOf<AppData?>(null)
        private set

    var error by mutableStateOf<String?>(null)
        private set

    init {
        viewModelScope.launch {
            try {
                val loaded = withContext(Dispatchers.IO) {
                    val text = getApplication<Application>().assets
                        .open("topics.json")
                        .bufferedReader(Charsets.UTF_8)
                        .use { it.readText() }
                    Json { ignoreUnknownKeys = true }.decodeFromString<AppData>(text)
                }
                data = loaded
            } catch (e: Exception) {
                error = e.message ?: "Data load nahi ho saka"
            }
        }
    }

    fun topic(id: Int): Topic? =
        data?.sections?.asSequence()?.flatMap { it.topics.asSequence() }?.firstOrNull { it.id == id }
}
