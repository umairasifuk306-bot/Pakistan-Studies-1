package com.pmsnotes.pakstudies.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.pmsnotes.pakstudies.data.AppViewModel

@Composable
fun AppNav(vm: AppViewModel) {
    val nav = rememberNavController()
    val data = vm.data
    val error = vm.error

    when {
        error != null -> ErrorScreen(error)
        data == null -> LoadingScreen()
        else -> NavHost(navController = nav, startDestination = "home") {

            composable("home") {
                HomeScreen(data.sections) { topicId -> nav.navigate("topic/$topicId") }
            }

            composable(
                route = "topic/{topicId}",
                arguments = listOf(navArgument("topicId") { type = NavType.IntType })
            ) { entry ->
                val topicId = entry.arguments?.getInt("topicId") ?: 0
                val topic = vm.topic(topicId)
                if (topic != null) {
                    TopicScreen(
                        topic = topic,
                        onBack = { nav.popBackStack() },
                        onHeading = { index -> nav.navigate("heading/$topicId/$index") }
                    )
                }
            }

            composable(
                route = "heading/{topicId}/{index}",
                arguments = listOf(
                    navArgument("topicId") { type = NavType.IntType },
                    navArgument("index") { type = NavType.IntType }
                )
            ) { entry ->
                val topicId = entry.arguments?.getInt("topicId") ?: 0
                val index = entry.arguments?.getInt("index") ?: 0
                val heading = vm.topic(topicId)?.headings?.getOrNull(index)
                if (heading != null) {
                    HeadingScreen(heading = heading, onBack = { nav.popBackStack() })
                }
            }
        }
    }
}
