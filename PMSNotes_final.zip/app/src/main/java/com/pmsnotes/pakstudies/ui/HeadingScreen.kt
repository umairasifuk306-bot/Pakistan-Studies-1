package com.pmsnotes.pakstudies.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pmsnotes.pakstudies.data.Heading

private val TAB_TITLES = listOf("Short", "Long", "Points")

@Composable
fun HeadingScreen(heading: Heading, onBack: () -> Unit) {
    var selected by rememberSaveable { mutableIntStateOf(0) }

    Scaffold(topBar = { AppTopBar(heading.title, onBack) }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Text(
                heading.title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 8.dp)
            )
            TabRow(selectedTabIndex = selected) {
                TAB_TITLES.forEachIndexed { index, title ->
                    Tab(
                        selected = selected == index,
                        onClick = { selected = index },
                        text = { Text(title) }
                    )
                }
            }
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                SelectionContainer {
                    Column(Modifier.fillMaxWidth()) {
                        when (selected) {
                            0 -> BodyText(heading.short)
                            1 -> BodyText(heading.long)
                            else -> heading.points.forEachIndexed { i, p ->
                                BodyText("${i + 1}. $p", bottomPadding = 10)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BodyText(text: String, bottomPadding: Int = 0) {
    Text(
        text = text,
        fontSize = 17.sp,
        lineHeight = 27.sp,
        modifier = Modifier.padding(bottom = bottomPadding.dp)
    )
}
