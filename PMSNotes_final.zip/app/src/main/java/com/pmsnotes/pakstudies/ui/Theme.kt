package com.pmsnotes.pakstudies.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val GreenPrimary = Color(0xFF01411C)
val GreenLight = Color(0xFFE8F5E9)

private val Colors = lightColorScheme(
    primary = GreenPrimary,
    onPrimary = Color.White,
    primaryContainer = GreenLight,
    onPrimaryContainer = GreenPrimary,
    secondary = Color(0xFF2E7D32),
    background = Color(0xFFFAFAFA),
    surface = Color.White
)

@Composable
fun PmsTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Colors, content = content)
}
