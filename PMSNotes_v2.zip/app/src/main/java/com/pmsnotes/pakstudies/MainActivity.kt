package com.pmsnotes.pakstudies

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.lifecycle.viewmodel.compose.viewModel
import com.pmsnotes.pakstudies.data.AppViewModel
import com.pmsnotes.pakstudies.ui.AppNav
import com.pmsnotes.pakstudies.ui.PmsTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: AppViewModel = viewModel()
            val base = LocalDensity.current
            CompositionLocalProvider(
                LocalDensity provides Density(base.density, base.fontScale * vm.fontScale)
            ) {
                PmsTheme { AppNav(vm) }
            }
        }
    }
}
