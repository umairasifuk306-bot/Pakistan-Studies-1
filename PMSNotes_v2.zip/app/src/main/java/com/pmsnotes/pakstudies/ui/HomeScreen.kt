package com.pmsnotes.pakstudies.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pmsnotes.pakstudies.data.AppViewModel
import com.pmsnotes.pakstudies.data.StudyMode
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun HomeScreen(
    vm: AppViewModel,
    onOpenTopic: (Int) -> Unit,
    onOpenNotes: (StudyMode) -> Unit,
    modifier: Modifier = Modifier
) {
    val sections = vm.data?.sections ?: return
    val topics = vm.allTopics
    val headingCount = topics.sumOf { it.headings.size }
    val last = vm.topic(vm.lastTopicId) ?: topics.firstOrNull()
    var showSoon by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier.fillMaxSize().background(PageBg),
        contentPadding = PaddingValues(bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { HeaderBanner() }

        item {
            DashboardCard(
                topicCount = topics.size,
                sectionCount = sections.size,
                headingCount = headingCount,
                modifier = Modifier.padding(horizontal = 12.dp)
            )
        }

        item {
            Column(
                Modifier.padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Tile("📚", "Short Notes", "Quick Revision",
                        Color(0xFFD6E9FB), Color(0xFF1976D2), Modifier.weight(1f)) { onOpenNotes(StudyMode.SHORT) }
                    Tile("📝", "Long Questions", "Detailed Answers",
                        Color(0xFFFFE3CF), Color(0xFFF57C00), Modifier.weight(1f)) { onOpenNotes(StudyMode.LONG) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Tile("✅", "Important Points", "Exam Preparation",
                        Color(0xFFDDF0D5), Color(0xFF2E7D32), Modifier.weight(1f)) { onOpenNotes(StudyMode.POINTS) }
                    Tile("📅", "Timeline", "Dates & Events",
                        Color(0xFFE6DDF7), Color(0xFF6A1B9A), Modifier.weight(1f)) { showSoon = true }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Tile("📊", "Headings & Subheadings", "All 400 headings",
                        Color(0xFFFFD9D9), Color(0xFFD32F2F), Modifier.weight(1f)) { onOpenNotes(StudyMode.BOTH) }
                    Tile("❓", "MCQs & Self Test", "Check Your Knowledge",
                        Color(0xFFD3F3EE), Color(0xFF00897B), Modifier.weight(1f)) { showSoon = true }
                }
            }
        }

        if (last != null) {
            item {
                Column(Modifier.padding(horizontal = 12.dp)) {
                    GreenBar("📖  Continue Reading", "View All") { onOpenNotes(StudyMode.BOTH) }
                    Card(
                        onClick = { onOpenTopic(last.id) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8E1)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier
                                    .size(76.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Brush.verticalGradient(listOf(GreenMid, GreenPrimary))),
                                contentAlignment = Alignment.Center
                            ) { Text("🏛️", fontSize = 34.sp) }
                            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                Text(last.title, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = GreenPrimary)
                                Text("Topic ${last.id}  •  Pakistan Studies-I", fontSize = 13.sp, color = Color(0xFF444444))
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = Color(0xFF1B7F3B),
                                    modifier = Modifier.padding(top = 6.dp)
                                ) {
                                    Text(
                                        "✓ Selected Topic",
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                                    )
                                }
                            }
                            Surface(shape = CircleShape, color = GoldYellow, modifier = Modifier.size(44.dp)) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text("›", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Column(Modifier.padding(horizontal = 12.dp)) {
                GreenBar("☰  Topic-wise Study", "View All") { onOpenNotes(StudyMode.BOTH) }
                Surface(
                    color = Color.White,
                    shape = RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp),
                    shadowElevation = 2.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        topics.take(5).forEachIndexed { index, topic ->
                            if (index > 0) {
                                Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFE6E6E6)))
                            }
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable { onOpenTopic(topic.id) }
                                    .padding(horizontal = 14.dp, vertical = 11.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                NumberBadge(topic.id, 32.dp)
                                Text(
                                    topic.title,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.weight(1f).padding(horizontal = 12.dp)
                                )
                                Text("›", fontSize = 22.sp, color = Color(0xFF333333))
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSoon) {
        AlertDialog(
            onDismissRequest = { showSoon = false },
            confirmButton = { TextButton(onClick = { showSoon = false }) { Text("OK") } },
            title = { Text("Jald aa raha hai") },
            text = { Text("Is feature ka data abhi notes mein shamil nahi hai.") }
        )
    }
}

@Composable
private fun HeaderBanner() {
    Box(
        Modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(GreenMid, GreenPrimary)))
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        PakistanFlag(Modifier.align(Alignment.TopStart).width(60.dp).height(40.dp))

        Surface(
            shape = RoundedCornerShape(50),
            color = Color(0xFF0E6B2F),
            border = BorderStroke(1.5.dp, Color(0xFF7ED957)),
            modifier = Modifier.align(Alignment.TopEnd)
        ) {
            Text(
                "👑 2026 Preparation",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }

        Column(
            Modifier.fillMaxWidth().padding(top = 36.dp, bottom = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("PMS", color = Color.White, fontSize = 52.sp, fontWeight = FontWeight.ExtraBold)
            Text("Pakistan Studies-I", color = GoldText, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            Text(
                "Study  •  Prepare  •  Excel",
                color = Color.White,
                fontSize = 17.sp,
                fontStyle = FontStyle.Italic,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

@Composable
private fun PakistanFlag(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val green = Color(0xFF01411C)
        drawRect(green)
        drawRect(Color.White, size = Size(w * 0.25f, h))
        val c = Offset(w * 0.62f, h * 0.5f)
        val r = h * 0.3f
        drawCircle(Color.White, r, c)
        drawCircle(green, r * 0.85f, Offset(c.x + r * 0.3f, c.y))
        val sc = Offset(c.x + r * 0.55f, c.y - r * 0.3f)
        val sr = r * 0.4f
        val path = Path()
        for (i in 0 until 10) {
            val ang = -Math.PI / 2 + i * Math.PI / 5
            val rad = if (i % 2 == 0) sr else sr * 0.4f
            val x = sc.x + rad * cos(ang).toFloat()
            val y = sc.y + rad * sin(ang).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        drawPath(path, Color.White)
    }
}

@Composable
private fun DashboardCard(
    topicCount: Int,
    sectionCount: Int,
    headingCount: Int,
    modifier: Modifier = Modifier
) {
    Box(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF0B5D2A), Color(0xFF01411C))))
            .padding(2.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF0B5D2A), Color(0xFF01411C))))
            .padding(14.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Surface(shape = RoundedCornerShape(10.dp), color = GoldYellow) {
                Text(
                    "YOUR STUDY DASHBOARD",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 15.sp,
                    color = Color(0xFF1B1B1B),
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)
                )
            }
            Row(
                Modifier.padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("📖", fontSize = 46.sp)
                Column(Modifier.padding(start = 14.dp)) {
                    Text("$topicCount Topics", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
                    Text(
                        "$sectionCount Sections  •  $headingCount Headings",
                        color = Color.White,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Start
                    )
                }
            }
        }
    }
}

@Composable
private fun Tile(
    emoji: String,
    title: String,
    subtitle: String,
    bg: Color,
    accent: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = modifier.height(84.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = bg),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            Modifier.fillMaxSize().padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(emoji, fontSize = 30.sp)
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color(0xFF1B1B1B), maxLines = 2)
                Text(subtitle, fontSize = 12.sp, color = Color(0xFF444444), maxLines = 1)
            }
            Surface(shape = CircleShape, color = accent.copy(alpha = 0.25f), modifier = Modifier.size(26.dp)) {
                Box(contentAlignment = Alignment.Center) {
                    Text("›", fontWeight = FontWeight.Bold, color = accent, fontSize = 18.sp)
                }
            }
        }
    }
}
