package com.pmsnotes.pakstudies.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pmsnotes.pakstudies.data.AppViewModel
import com.pmsnotes.pakstudies.data.StudyMode

@Composable
fun NotesScreen(
    vm: AppViewModel,
    onBack: (() -> Unit)?,
    onTopic: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val sections = vm.data?.sections ?: emptyList()
    Column(modifier.fillMaxSize().background(PageBg)) {
        AppTopBar(vm.mode.label, onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Text(
                    vm.mode.hint,
                    fontSize = 13.sp,
                    color = Color(0xFF555555)
                )
            }
            sections.forEach { section ->
                item(key = "section_${section.id}") { SectionHeader(section) }
                items(section.topics, key = { it.id }) { topic ->
                    TopicCard(topic) { onTopic(topic.id) }
                }
            }
        }
    }
}

@Composable
fun BookmarksScreen(
    vm: AppViewModel,
    onTopic: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val saved = vm.allTopics.filter { it.id in vm.bookmarks }
    Column(modifier.fillMaxSize().background(PageBg)) {
        AppTopBar("Bookmarks")
        if (saved.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text(
                    "Abhi koi bookmark nahi.\nKisi topic ke andar ☆ dabayein.",
                    textAlign = TextAlign.Center,
                    fontSize = 16.sp,
                    color = Color(0xFF555555)
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(saved, key = { it.id }) { topic ->
                    TopicCard(topic) { onTopic(topic.id) }
                }
            }
        }
    }
}

@Composable
fun ProgressScreen(vm: AppViewModel, modifier: Modifier = Modifier) {
    val sections = vm.data?.sections ?: emptyList()
    val total = vm.allTopics.size
    val done = vm.allTopics.count { it.id in vm.visited }
    val fraction = if (total == 0) 0f else done.toFloat() / total

    Column(modifier.fillMaxSize().background(PageBg)) {
        AppTopBar("Progress")
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Overall Progress", fontWeight = FontWeight.Bold, color = GreenPrimary)
                        Text(
                            "$done / $total topics parhe",
                            fontSize = 26.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.padding(vertical = 6.dp)
                        )
                        ProgressBar(fraction)
                        Text(
                            "Bookmarks: ${vm.bookmarks.size}",
                            fontSize = 14.sp,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }
            }
            items(sections, key = { it.id }) { section ->
                val sectionDone = section.topics.count { it.id in vm.visited }
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text(
                            "${section.id}. ${section.title}",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp
                        )
                        Text(
                            "$sectionDone / ${section.topics.size}",
                            fontSize = 13.sp,
                            color = Color(0xFF555555),
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                        ProgressBar(
                            if (section.topics.isEmpty()) 0f else sectionDone.toFloat() / section.topics.size
                        )
                    }
                }
            }
            item {
                Text(
                    "Topic tab khulne par woh \"parha hua\" ginta hai.",
                    fontSize = 12.sp,
                    color = Color(0xFF777777)
                )
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: AppViewModel, modifier: Modifier = Modifier) {
    var confirmReset by remember { mutableStateOf(false) }
    val options = listOf(
        "Small" to 0.9f,
        "Medium" to 1.0f,
        "Large" to 1.2f,
        "Extra Large" to 1.4f
    )

    Column(modifier.fillMaxSize().background(PageBg)) {
        AppTopBar("Settings")
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Text size", fontWeight = FontWeight.Bold, color = GreenPrimary)
                        options.forEach { (label, scale) ->
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable { vm.updateFontScale(scale) }
                                    .padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(selected = vm.fontScale == scale, onClick = null)
                                Text(label, modifier = Modifier.padding(start = 12.dp))
                            }
                        }
                    }
                }
            }
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Progress aur bookmarks", fontWeight = FontWeight.Bold, color = GreenPrimary)
                        Button(
                            onClick = { confirmReset = true },
                            modifier = Modifier.padding(top = 8.dp)
                        ) { Text("Reset karein") }
                    }
                }
            }
            item {
                Text(
                    "PMS Pakistan Studies-I\n80 topics, 400 headings. Offline chalti hai.",
                    fontSize = 13.sp,
                    color = Color(0xFF666666),
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Reset karein?") },
            text = { Text("Parhe hue topics aur bookmarks mit jayenge.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.resetProgress()
                    confirmReset = false
                }) { Text("Haan") }
            },
            dismissButton = {
                TextButton(onClick = { confirmReset = false }) { Text("Nahi") }
            }
        )
    }
}
