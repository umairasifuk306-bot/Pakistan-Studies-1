import re, json, sys

src = sys.argv[1]
out = sys.argv[2]
text = open(src, encoding="utf-8").read()

def clean(s):
    s = s.replace("**", "").strip()
    return s

sections, cur_sec, cur_topic, cur_head = [], None, None, None
for raw in text.splitlines():
    line = raw.strip()
    if not line:
        continue
    if line.startswith("# "):
        m = re.match(r"# ([A-D])\. (.+)", line)
        if m:
            cur_sec = {"id": m.group(1), "title": m.group(2).strip(), "topics": []}
            sections.append(cur_sec)
            cur_topic = cur_head = None
    elif line.startswith("## "):
        m = re.match(r"## (\d+)\. (.+)", line)
        if m and cur_sec:
            cur_topic = {"id": int(m.group(1)), "title": m.group(2).strip(),
                         "short": "", "long": "", "headings": []}
            cur_sec["topics"].append(cur_topic)
            cur_head = None
    elif line.startswith("### "):
        if cur_topic:
            cur_head = {"title": line.replace("### ▪", "").replace("###", "").strip(),
                        "short": "", "long": "", "points": []}
            cur_topic["headings"].append(cur_head)
    elif cur_topic:
        c = clean(line)
        if c.startswith("◉ Short Detail:"):
            cur_topic["short"] = c.split(":", 1)[1].strip()
        elif c.startswith("◆ Long Detail:"):
            cur_topic["long"] = c.split(":", 1)[1].strip()
        elif cur_head is not None:
            if c.startswith("Short Detail:"):
                cur_head["short"] = c.split(":", 1)[1].strip()
            elif c.startswith("Long Detail:"):
                cur_head["long"] = c.split(":", 1)[1].strip()
            elif c.startswith("Study points from outline:"):
                pts = c.split(":", 1)[1]
                cur_head["points"] = [p.strip() for p in pts.split("|") if p.strip()]

json.dump({"sections": sections}, open(out, "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)

# validation
topics = [t for s in sections for t in s["topics"]]
heads = [h for t in topics for h in t["headings"]]
print("sections:", len(sections), [(s["id"], len(s["topics"])) for s in sections])
print("topics:", len(topics), "ids contiguous:", [t["id"] for t in topics] == list(range(1, len(topics)+1)))
print("headings:", len(heads))
print("topics missing short/long:", [t["id"] for t in topics if not t["short"] or not t["long"]])
print("topics without 5 headings:", [(t["id"], len(t["headings"])) for t in topics if len(t["headings"]) != 5])
print("headings missing short/long/points:", sum(1 for h in heads if not (h["short"] and h["long"] and h["points"])))
